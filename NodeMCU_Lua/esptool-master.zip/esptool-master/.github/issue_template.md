(Please delete any lines which don't apply.)

* Operating system:
* Python version: (`python -V` to check this)
* ESP hardware in use:

# Full esptool.py command line as run:

# Full output from esptool.py (please copy and paste all lines of output)

# What is the expected behaviour?

# Do you have any other information from investigating this?

# Is there any other information you can think of which will help us reproduce this problem?
